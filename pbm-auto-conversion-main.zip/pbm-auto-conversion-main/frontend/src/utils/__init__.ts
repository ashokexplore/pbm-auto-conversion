// Utility functions

