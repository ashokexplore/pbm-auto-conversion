# Pydantic schemas for API

